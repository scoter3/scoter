document.getElementById('registerForm').addEventListener('submit', function (e) {
    e.preventDefault();
    
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    const userExists = users.some(user => user.username === username);

    if (userExists) {
        document.getElementById('registerMessage').innerText = 'Username already exists!';
    } else {
        users.push({ username, email, password });
        localStorage.setItem('users', JSON.stringify(users));
        document.getElementById('registerMessage').innerText = 'Registration successful! You can now log in.';
    }
});

document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        document.getElementById('loginMessage').innerText = 'Login successful! Redirecting to map...';
        setTimeout(() => {
            showMapSection();
        }, 2000);
    } else {
        document.getElementById('loginMessage').innerText = 'Invalid username or password!';
    }
});

function showMapSection() {
    document.getElementById('login').style.display = 'none';
    document.getElementById('register').style.display = 'none';
    document.getElementById('map').style.display = 'block';

    // Initialize the map
    initMap();
}

function initMap() {
    // Create the map and set its view to the Eiffel Tower's coordinates
    const map = L.map('mapCanvas').setView([48.8588443, 2.2943506], 13); // Eiffel Tower coordinates

    // Add a tile layer to the map
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap'
    }).addTo(map);

    // Add a marker for the Eiffel Tower
    L.marker([48.8588443, 2.2943506]).addTo(map)
        .bindPopup('Eiffel Tower')
        .openPopup();
}

